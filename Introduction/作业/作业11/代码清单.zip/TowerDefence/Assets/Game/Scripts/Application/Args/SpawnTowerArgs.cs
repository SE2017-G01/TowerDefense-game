﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

public class SpawnTowerArgs
{
    public Vector3 Position;
    public int TowerID;
}