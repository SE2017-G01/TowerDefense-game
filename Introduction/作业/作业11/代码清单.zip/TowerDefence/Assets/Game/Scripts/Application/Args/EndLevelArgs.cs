﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class EndLevelArgs
{
    public int LevelID;

    public bool IsSuccess; //是否成功
}