﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class TowerInfo
{
    public int ID;
    public string PrefabName;
    public string NormalIcon;
    public string DisabledIcon;
    public int MaxLevel;
    public int BasePrice;
    public float ShotRate;
    public float GuardRange;
    public int UseBulletID;
}