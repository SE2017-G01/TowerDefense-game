﻿using UnityEngine;
using System.Collections;

public class Card
{
    public int LevelID;
    public string CardImage;
    public bool IsLocked;
}