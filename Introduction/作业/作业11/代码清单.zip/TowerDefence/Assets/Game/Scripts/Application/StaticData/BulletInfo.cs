﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class BulletInfo
{
    public int ID;
    public string PrefabName;
    public float BaseSpeed; //基本速度
    public int BaseAttack;  //基本攻击力
}