﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class MonsterInfo
{
    public int ID;
    public int Hp;
    public float MoveSpeed;
    public int Price;
}