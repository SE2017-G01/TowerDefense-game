﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Silly : CommonMonster
{
    public static string Id = "Silly";

}
