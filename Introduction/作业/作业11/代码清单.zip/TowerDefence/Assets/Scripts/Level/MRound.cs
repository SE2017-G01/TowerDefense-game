﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

class MRound
{
    public List<KeyValuePair<CommonMonster,int>> MonsterList = new List<KeyValuePair<CommonMonster, int>>();
}
